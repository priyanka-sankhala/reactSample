import React from 'react';
import {Field,ErrorMessage} from 'formik'
import TextError from './TextError';

function Select(props) {
    const {name} = props
    return (
        <div>
            <label name={name} htmlFor="{name"/>
            <Field as ="select" name={name} />
            <ErrorMessage name={name} component={TextError} />
        </div>
    );
}

export default Select;