import React from 'react';
import { Formik } from 'formik';
import InputText from './InputText';

const FormComponet =({command,...props})=>{
    console.log("command", command);
    switch (command) {
        case "TextInput":
            return( <InputText {...props } /> )
            break;
        case "TextAera":
            
        default:
            return null
            break;
    }
}

export default FormComponet